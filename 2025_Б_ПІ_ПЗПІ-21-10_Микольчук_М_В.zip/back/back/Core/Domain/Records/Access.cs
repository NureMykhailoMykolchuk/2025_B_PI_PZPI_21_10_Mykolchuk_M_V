﻿namespace back.Core.Domain.Records
{
    public enum Access : byte
    {
        None = 0,
        Reader = 1,
        CoAuthor = 2
    }
}
