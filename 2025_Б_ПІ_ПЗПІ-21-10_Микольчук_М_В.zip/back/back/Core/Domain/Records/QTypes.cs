﻿namespace back.Core.Domain.Records
{
    public enum QTypes : byte
    {
        TrueFalse = 1,
        MultipleChoice = 2,
        Handwritten = 3,
        Audio = 4
    }

}
