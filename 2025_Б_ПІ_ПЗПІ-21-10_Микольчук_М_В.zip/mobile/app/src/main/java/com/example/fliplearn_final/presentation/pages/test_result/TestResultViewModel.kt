package com.example.fliplearn_final.presentation.pages.test_result

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class TestResultViewModel @Inject constructor(): ViewModel() {
}