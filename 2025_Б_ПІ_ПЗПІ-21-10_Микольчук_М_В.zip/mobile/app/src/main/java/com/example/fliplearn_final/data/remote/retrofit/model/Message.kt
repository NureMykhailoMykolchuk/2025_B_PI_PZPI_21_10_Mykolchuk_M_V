package com.example.fliplearn_final.data.remote.retrofit.model

data class Message(
    val role: String,
    val content: String
)