// src/i18n.js
import i18n from "i18next";
import { initReactI18next } from "react-i18next";

// Import translation files
import en from "./locales/en.json";
import ua from "./locales/ua.json";

const language = localStorage.getItem("language");

// Initialize i18n
i18n.use(initReactI18next).init({
  resources: {
    en: { translation: en },
    ua: { translation: ua },
  },
  lng: language || "ua", // default language
  fallbackLng: language || "ua", // fallback language
  interpolation: {
    escapeValue: false, // React already escapes values
  },
});

export default i18n;
