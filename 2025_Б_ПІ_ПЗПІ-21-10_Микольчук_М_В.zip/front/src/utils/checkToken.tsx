const token = localStorage.getItem("token");

export default token;
