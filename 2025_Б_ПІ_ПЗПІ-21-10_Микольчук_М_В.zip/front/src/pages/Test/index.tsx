import { useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import audio from "../../assets/speaker-button.svg";
import { useTranslation } from "react-i18next";

export const TestPage = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const testData = location.state?.testData;

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [GivenAnswer, setGivenAnswer] = useState(null);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [incorrectAnswers, setIncorrectAnswers] = useState(0);
  const [answersLog, setAnswersLog] = useState([]);
  const [timerId, setTimerId] = useState(null);
  const [localSeconds, setLocalSeconds] = useState(0);

  const currentQuestion = testData?.questions[currentQuestionIndex];
  const totalQuestions = testData?.questions.length;

  useEffect(() => {
    if (!testData) {
      // If test data is not passed, return to dictionary page
      console.error("Test data is missing");
      navigate("/dictionaries");
      return;
    }

    setProgress(((currentQuestionIndex + 1) / totalQuestions) * 100);
  }, [currentQuestionIndex, totalQuestions, testData, navigate]);

  // Start local timer
  useEffect(() => {
    const interval = setInterval(() => {
      setLocalSeconds((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Clear timer when component unmounts
  useEffect(() => {
    return () => {
      if (timerId) {
        clearInterval(timerId);
      }
    };
  }, []);

  const formatTime = (totalSeconds: any) => {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
    const formattedSeconds = seconds < 10 ? `0${seconds}` : seconds;
    return `${formattedMinutes}:${formattedSeconds}`;
  };

  // const handleTimeUp = () => {
  //   if (GivenAnswer !== null) return; // Skip if already answered

  //   // Log the answer as incorrect since time ran out
  //   const updatedLog = [
  //     ...answersLog,
  //     {
  //       ...currentQuestion,
  //       GivenAnswer: "Time expired",
  //       IsGivenCorrectAnswer: false,
  //     },
  //   ];

  //   setAnswersLog(updatedLog);
  //   setIncorrectAnswers(incorrectAnswers + 1);

  //   // Move to the next question or finish the test
  //   if (currentQuestionIndex < totalQuestions - 1) {
  //     setCurrentQuestionIndex(currentQuestionIndex + 1);
  //     setGivenAnswer(null);
  //   } else {
  //     finishTest(updatedLog, false);
  //   }
  // };

  const finishTest = (finalLog: any, isLastAnswerCorrect: any) => {
    console.log("Test completed!");

    // Calculate total incorrect answers
    const totalIncorrect = !isLastAnswerCorrect ? incorrectAnswers + 1 : incorrectAnswers;

    const resultData = {
      dictionaryId: testData.dictionariesInvolved[0].id,
      dictionaryName: testData.dictionariesInvolved[0].title,
      correctAnswers: isLastAnswerCorrect ? correctAnswers + 1 : correctAnswers,
      incorrectAnswers: totalIncorrect,
      questions: finalLog,
      testData: testData,
      fromLanguage: testData.fromLanguage,
      toLanguage: testData.toLanguage,
      totalTime: localSeconds,
    };

    // Clear any existing timer before navigation
    if (timerId) {
      clearInterval(timerId);
    }

    // Navigate to the result page
    navigate("/test-result", { state: { resultData } });
  };

  const handleAnswerClick = (answer: any, index: any) => {
    if (GivenAnswer !== null) return;
    setGivenAnswer(index);

    // Clear the timer when an answer is selected
    if (timerId) {
      clearInterval(timerId);
    }

    const IsGivenCorrectAnswer = answer.IsGivenCorrectAnswer;

    // Save entire currentQuestion object and add IsGivenCorrectAnswer and GivenAnswer fields
    const currentAnswer = {
      ...currentQuestion,
      IsGivenCorrectAnswer,
      GivenAnswer: answer.text || answer.choice.toString(),
    };

    // Update the answersLog with the current answer
    const updatedLog: any = [...answersLog, currentAnswer];
    setAnswersLog(updatedLog);

    if (IsGivenCorrectAnswer) {
      setCorrectAnswers(correctAnswers + 1);
    } else {
      setIncorrectAnswers(incorrectAnswers + 1);
    }

    setTimeout(() => {
      if (currentQuestionIndex < totalQuestions - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setGivenAnswer(null);
      } else {
        // Test completed
        finishTest(updatedLog, IsGivenCorrectAnswer);
      }
    }, 2000);
  };

  if (!testData) {
    return <div className="text-center p-10">{t("test.loadingTestData")}</div>;
  }

  return (
    <div className="flex flex-col gap-10 items-center">
      <div className="flex justify-center relative w-full">
        <span>{testData?.dictionariesInvolved[0]?.title || t("test.test")}</span>
        <span
          className="absolute right-[20px] top-[20px] cursor-pointer "
          onClick={() => navigate("/dictionaries")}
        >
          X
        </span>
      </div>

      <div className="w-[1000px] flex flex-col gap-10">
        <div className="flex flex-col items-end gap-4">
          <div className="w-full flex gap-3">
            <span>{currentQuestionIndex + 1}</span>
            <div className="flex-1 bg-[#EEEEEE] rounded-[10px] overflow-hidden">
              <div
                className="bg-[#B3BCFF] rounded-[10px] h-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <span>{totalQuestions}</span>
          </div>
        </div>

        <div className="p-6 bg-white rounded-lg shadow-lg w-full gap-8 flex flex-col h-[400px] min-h-[400px]">
          {currentQuestion?.type === "trueFalse" ? (
            <>
              <div className="flex w-full justify-between">
                <div className="flex flex-col gap-1 w-[50%]">
                  <span>{t("test.term")}</span>
                  <span className="text-3xl">{currentQuestion?.term}</span>
                </div>
                <div className="w-[2px] bg-[#D9D9D9]" />
                <div className="flex flex-col gap-1 w-[50%] pl-[50px]">
                  <span>{t("test.meaning")}</span>
                  <span className="text-3xl">{currentQuestion?.translation}</span>
                </div>
              </div>
              <span>{t("test.selectAnswer")}</span>
              <div className="flex w-full flex-wrap justify-between gap-3 mt-3">
                {currentQuestion?.answers.map((answer: any, index: any) => (
                  <div
                    key={index}
                    onClick={() => handleAnswerClick(answer, index)}
                    className={`w-[45%] rounded-[8px] p-3 border-2 border-gray-500 flex gap-3 cursor-pointer hover:bg-gray-200 transition-all duration-300 
                    ${
                      GivenAnswer === index
                        ? answer.IsGivenCorrectAnswer
                          ? "bg-green-300"
                          : "bg-red-300"
                        : ""
                    }`}
                  >
                    <span className="rounded-full border text-[#8B8B8B] w-[25px] h-[25px] flex justify-center bg-[#EEEEEE]">
                      {index + 1}
                    </span>
                    <span>{answer.choice.toString()}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="w-full flex justify-between items-center">
                <span>{t("test.term")}</span>
                <img src={audio} alt="" />
              </div>
              <span className="text-3xl">{currentQuestion?.term || currentQuestion?.translation}</span>
              <div className="mt-6">
                <span>{t("test.chooseCorrectDefinition")}</span>
                <div className="flex w-full flex-wrap justify-between gap-3 mt-3">
                  {currentQuestion?.answers.map((answer: any, index: any) => (
                    <div
                      key={index}
                      onClick={() => handleAnswerClick(answer, index)}
                      className={`w-[45%] rounded-[8px] p-3 border-2 border-gray-500 flex gap-3 cursor-pointer hover:bg-gray-200 transition-all duration-300 
                      ${
                        GivenAnswer === index
                          ? answer.IsGivenCorrectAnswer
                            ? "bg-green-300"
                            : "bg-red-300"
                          : ""
                      }`}
                    >
                      <span className="rounded-full border text-[#8B8B8B] w-[25px] h-[25px] flex justify-center bg-[#EEEEEE]">
                        {index + 1}
                      </span>
                      <span>{answer.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        <p className="text-2xl w-full text-center text-[#4F4F4F]">{formatTime(localSeconds)}</p>
      </div>
    </div>
  );
};
