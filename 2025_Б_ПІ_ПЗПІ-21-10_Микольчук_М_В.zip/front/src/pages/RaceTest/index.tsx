import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import audio from "../../assets/speaker-button.svg";
import { HubConnectionBuilder, HttpTransportType } from "@microsoft/signalr";
import { useTranslation } from "react-i18next";

export const RaceTest = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const testData = location.state?.testData;
  const { id: roomId } = useParams();

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [GivenAnswer, setGivenAnswer] = useState(null);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [incorrectAnswers, setIncorrectAnswers] = useState(0);
  const [answersLog, setAnswersLog] = useState([]);
  const [timerId, setTimerId] = useState(null);
  const connectionRef = useRef<any>(null);

  // State for global timer
  const [globalTimeRemaining, setGlobalTimeRemaining] = useState(testData?.totalTimeInSeconds || null);
  const [globalTimerDisplay, setGlobalTimerDisplay] = useState<any>(null);

  const currentQuestion = testData?.questions[currentQuestionIndex];
  const totalQuestions = testData?.questions.length;

  // Setup connection to RoomHub
  useEffect(() => {
    if (!roomId) return;

    const token = localStorage.getItem("token");

    const connection = new HubConnectionBuilder()
      .withUrl(`https://localhost:7288/room?access_token=${token}`, {
        transport: HttpTransportType.WebSockets,
      })
      .withAutomaticReconnect()
      .build();

    const setupConnection = async () => {
      try {
        // Handler for updating global timer
        connection.on("UpdateRemainingTime", (remainingSeconds) => {
          setGlobalTimeRemaining(remainingSeconds);
          // Format time for display
          const minutes = Math.floor(remainingSeconds / 60);
          const seconds = remainingSeconds % 60;
          setGlobalTimerDisplay(`${minutes}:${seconds < 10 ? "0" : ""}${seconds}`);
        });

        // Handler for when test time expires
        connection.on("CollectAnswersAndFinishRace", () => {
          console.log("Time's up! Race is finished.");

          // Prepare final answer data
          const finalLog: any = [...answersLog];

          // Mark remaining unanswered questions as incorrect
          if (currentQuestionIndex < totalQuestions) {
            // Include the current question if it hasn't been answered
            if (GivenAnswer === null) {
              finalLog.push({
                ...currentQuestion,
                questionIndex: currentQuestionIndex,
                question: currentQuestion.term,
                translation: currentQuestion.translation,
                type: currentQuestion.type,
                GivenAnswer: "Time expired",
                IsGivenCorrectAnswer: false,
              });
            }

            // Add all remaining questions as incorrect
            for (let i = currentQuestionIndex + 1; i < totalQuestions; i++) {
              const skippedQuestion = testData.questions[i];
              finalLog.push({
                ...skippedQuestion,
                questionIndex: i,
                question: skippedQuestion.term,
                translation: skippedQuestion.translation,
                type: skippedQuestion.type,
                GivenAnswer: "Time expired",
                IsGivenCorrectAnswer: false,
              });
            }
          }

          // Send results and redirect to result page
          finishTest(finalLog, false);
        });

        await connection.start();
        console.log("Connected to RoomHub from RaceTestComponent");
        connectionRef.current = connection;

        // Join the room
        await connection.invoke("JoinRoom", roomId);
      } catch (error) {
        console.error("Failed to connect to RoomHub:", error);
      }
    };

    setupConnection();

    return () => {
      if (connectionRef.current) {
        connectionRef.current.stop();
        console.log("Disconnected from RoomHub");
      }
    };
  }, [roomId]);

  // Initialize global timer if data was passed during transition
  useEffect(() => {
    if (testData?.totalTimeInSeconds) {
      setGlobalTimeRemaining(testData.totalTimeInSeconds);

      // Format time for display
      const minutes = Math.floor(testData.totalTimeInSeconds / 60);
      const seconds = testData.totalTimeInSeconds % 60;
      setGlobalTimerDisplay(`${minutes}:${seconds < 10 ? "0" : ""}${seconds}`);
    }
  }, [testData]);

  useEffect(() => {
    if (!testData) {
      // If test data is not passed, return to rooms page
      console.error("Test data is missing");
      navigate("/rooms");
      return;
    }

    setProgress(((currentQuestionIndex + 1) / totalQuestions) * 100);
  }, [currentQuestionIndex, totalQuestions, testData, navigate]);

  // Clear timer when component unmounts
  useEffect(() => {
    return () => {
      if (timerId) {
        clearInterval(timerId);
      }
    };
  }, []);

  const finishTest = async (finalLog: any, isLastAnswerCorrect: any) => {
    console.log("Race completed!");

    // Calculate total incorrect answers - original count plus any skipped questions
    const totalIncorrect = !isLastAnswerCorrect ? incorrectAnswers + 1 : incorrectAnswers;

    const resultData = {
      dictionaryId: testData.dictionariesInvolved[0].id,
      dictionaryName: testData.dictionariesInvolved[0].title,
      correctAnswers: isLastAnswerCorrect ? correctAnswers + 1 : correctAnswers,
      incorrectAnswers: totalIncorrect,
      questions: finalLog,
      testData: testData,
      fromLanguage: testData.fromLanguage,
      toLanguage: testData.toLanguage,
      roomId: roomId,
    };

    try {
      // Wait for SignalR call to complete before navigation
      await connectionRef.current.invoke(
        "FinishRace",
        roomId,
        finalLog,
        isLastAnswerCorrect ? correctAnswers + 1 : correctAnswers,
        !isLastAnswerCorrect ? incorrectAnswers + 1 : incorrectAnswers
      );

      console.log("Race results submitted");
    } catch (err) {
      console.error("Failed to submit race results:", err);
    }

    // Clear any existing timer before navigation
    if (timerId) {
      clearInterval(timerId);
    }

    // Navigate after SignalR call is complete
    navigate("/test-result", { state: { resultData, isRace: true } });
  };

  const handleAnswerClick = (answer: any, index: any) => {
    if (GivenAnswer !== null) return;
    setGivenAnswer(index);

    // Clear the timer when an answer is selected
    if (timerId) {
      clearInterval(timerId);
    }

    const IsGivenCorrectAnswer = answer.isCorrect;

    // Save entire currentQuestion object and add IsGivenCorrectAnswer and GivenAnswer fields
    const currentAnswer = {
      ...currentQuestion,
      IsGivenCorrectAnswer,
      GivenAnswer: answer.text || answer.choice.toString(),
    };

    // Update the answersLog with the current answer
    const updatedLog: any = [...answersLog, currentAnswer];
    setAnswersLog(updatedLog);

    if (IsGivenCorrectAnswer) {
      setCorrectAnswers(correctAnswers + 1);
    } else {
      setIncorrectAnswers(incorrectAnswers + 1);
    }

    setTimeout(() => {
      if (currentQuestionIndex < totalQuestions - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setGivenAnswer(null);
      } else {
        // Test completed
        finishTest(updatedLog, IsGivenCorrectAnswer);
      }
    }, 2000);
  };

  if (!testData) {
    return <div className="text-center p-10">{t("test.loadingTestData")}</div>;
  }

  return (
    <div className="flex flex-col gap-10 items-center">
      <div className="flex justify-center relative w-full">
        <span>{testData?.dictionariesInvolved[0]?.title || t("test.raceTestTitle")}</span>
        <span className="absolute right-[20px] top-[20px] cursor-pointer " onClick={() => navigate("/rooms")}>
          X
        </span>
      </div>

      <div className="w-[1000px] flex flex-col gap-10">
        <div className="flex flex-col items-end gap-4">
          <div className="w-full flex gap-3">
            <span>{currentQuestionIndex + 1}</span>
            <div className="flex-1 bg-[#EEEEEE] rounded-[10px] overflow-hidden">
              <div
                className="bg-[#B3BCFF] rounded-[10px] h-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <span>{totalQuestions}</span>
          </div>
        </div>

        <div className="p-6 bg-white rounded-lg shadow-lg w-full gap-8 flex flex-col h-[400px] min-h-[400px]">
          {currentQuestion?.type === "trueFalse" ? (
            <>
              <div className="flex w-full justify-between">
                <div className="flex flex-col gap-1 w-[50%]">
                  <span>{t("test.term")}</span>
                  <span className="text-3xl">{currentQuestion?.term}</span>
                </div>
                <div className="w-[2px] bg-[#D9D9D9]" />
                <div className="flex flex-col gap-1 w-[50%] pl-[50px]">
                  <span>{t("test.meaning")}</span>
                  <span className="text-3xl">{currentQuestion?.translation}</span>
                </div>
              </div>
              <span>{t("test.selectAnswer")}</span>
              <div className="flex w-full flex-wrap justify-between gap-3 mt-3">
                {currentQuestion?.answers.map((answer: any, index: any) => (
                  <div
                    key={index}
                    onClick={() => handleAnswerClick(answer, index)}
                    className={`w-[45%] rounded-[8px] p-3 border-2 border-gray-500 flex gap-3 cursor-pointer hover:bg-gray-200 transition-all duration-300 
                    ${GivenAnswer === index ? (answer.isCorrect ? "bg-green-300" : "bg-red-300") : ""}`}
                  >
                    <span className="rounded-full border text-[#8B8B8B] w-[25px] h-[25px] flex justify-center bg-[#EEEEEE]">
                      {index + 1}
                    </span>
                    <span>{answer.choice.toString()}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="w-full flex justify-between items-center">
                <span>{t("test.term")}</span>
                <img src={audio} alt="" />
              </div>
              <span className="text-3xl">{currentQuestion?.term || currentQuestion?.translation}</span>
              <div className="mt-6">
                <span>{t("test.chooseCorrectDefinition")}</span>
                <div className="flex w-full flex-wrap justify-between gap-3 mt-3">
                  {currentQuestion?.answers.map((answer: any, index: any) => (
                    <div
                      key={index}
                      onClick={() => handleAnswerClick(answer, index)}
                      className={`w-[45%] rounded-[8px] p-3 border-2 border-gray-500 flex gap-3 cursor-pointer hover:bg-gray-200 transition-all duration-300 
                      ${GivenAnswer === index ? (answer.isCorrect ? "bg-green-300" : "bg-red-300") : ""}`}
                    >
                      <span className="rounded-full border text-[#8B8B8B] w-[25px] h-[25px] flex justify-center bg-[#EEEEEE]">
                        {index + 1}
                      </span>
                      <span>{answer.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        <p className="text-2xl w-full text-center text-[#4F4F4F]">
          {globalTimerDisplay || `${globalTimeRemaining} ${t("test.seconds")}`}
        </p>
      </div>
    </div>
  );
};
