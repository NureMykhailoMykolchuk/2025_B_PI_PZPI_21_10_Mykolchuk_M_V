import React, { useState } from "react";
import { motion } from "framer-motion";

import "./index.scss";

interface FlipCardProps {
  word: string;
  translate: string;
}

const FlipCard: React.FC<FlipCardProps> = ({ word, translate }) => {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  return (
    <div className="card-container" onClick={handleFlip}>
      <motion.div
        className="card"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.3 }}
        style={{ perspective: 1000 }}
      >
        <motion.div className="card-front">
          <span>{word}</span>
        </motion.div>
        <motion.div className="card-back">
          <span>{translate}</span>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default FlipCard;
