import Slider from "react-slick";
import PageWrapper from "../../components/PageWrapper";
import sliderSettings from "./sliderSettings";
import FlipCard from "./Card";
import speaker from "../../assets/speaker-button.svg";
import warning from "../../assets/warning.svg";
import moreInfo from "../../assets/more-button.svg";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./index.scss";
import { CircularProgress, MenuItem, Modal, Select, Tooltip } from "@mui/material";
import { useEffect, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import axios from "axios";
import { formatDate } from "../../utils/formatDate";
import { slicedText } from "../../utils/slicedText";
import { AccessModal } from "./AccessModal";

interface Card {
  cardId: number;
  term: string;
  meaning: string | null;
  translation: string;
  status?: string;
}

interface Vocabulary {
  id: number;
  title: string;
  description: string;
  fromLang: string;
  toLang: string;
  label: string;
  isPublic: boolean;
  creatorId: number;
  creationDate: string;
  lastModified: string | null;
  cards: Card[];
  cefr: string;
}

interface IVocabulary {
  dictionary: Vocabulary;
  access: string;
}

const ELEVENLABS_VOICES = {
  default: "ErXwobaYiN019PkySvjV", // Default to English Josh
};

export const WORDS_STATUSES = [
  { value: "all", label: "statusFilters.all" },
  { value: "with_warnings", label: "statusFilters.withWarnings" },
  { value: "no_warnings", label: "statusFilters.noWarnings" },
];

const Vocabulary = () => {
  const { t } = useTranslation();
  const [vocabulary, setVocabulary] = useState<IVocabulary | null>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [loading, setLoading] = useState(true);
  const [accessModalView, setAccessModalView] = useState(false);
  const [vocabularyOptions, setVocabularyOptions] = useState(false);
  const [error, setError] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const { id } = useParams();
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  // ElevenLabs configuration
  const ELEVENLABS_API_KEY = "sk_e3d554648c45dceaf9dbe4526efda0e0e8d2fd8798696c3b";
  const ELEVENLABS_BASE_URL = "https://api.elevenlabs.io/v1";

  useEffect(() => {
    if (token) {
      getDictionary();
    }
  }, [id]);

  const getDictionary = () => {
    axios
      .get(`https://localhost:7288/Dictionary/full?dictionaryId=${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        setVocabulary(response.data);
      })
      .catch((error) => {
        console.error(`${t("vocabulary.loadingError")} ${error.response?.data || error.message}`);
        setError(true);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const deleteVocabulary = () => {
    axios
      .delete(`https://localhost:7288/Dictionary`, {
        params: {
          dictionaryId: id,
        },
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(() => {
        navigate("/");
      })
      .catch((error) => {
        console.error(`${t("vocabulary.loadingError")} ${error.response?.data || error.message}`);
      });
  };

  // Enhanced speech function using ElevenLabs
  const speakWithElevenLabs = useCallback(
    async (text: string, lang: string): Promise<void> => {
      if (!ELEVENLABS_API_KEY) {
        console.warn("ElevenLabs API key not found, falling back to Web Speech API");
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = lang;
        window.speechSynthesis.speak(utterance);
        return;
      }

      try {
        const voiceId = ELEVENLABS_VOICES.default;

        const response = await axios.post(
          `${ELEVENLABS_BASE_URL}/text-to-speech/${voiceId}`,
          {
            text: text,
            model_id: "eleven_multilingual_v2",
            voice_settings: {
              stability: 0.5,
              similarity_boost: 0.8,
              style: 0.2,
              use_speaker_boost: true,
            },
          },
          {
            headers: {
              Accept: "audio/mpeg",
              "Content-Type": "application/json",
              "xi-api-key": ELEVENLABS_API_KEY,
            },
            responseType: "blob",
          }
        );

        // Create audio blob and play it
        const audioBlob = new Blob([response.data], { type: "audio/mpeg" });
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);

        return new Promise<void>((resolve, reject) => {
          audio.onended = () => {
            URL.revokeObjectURL(audioUrl);
            resolve();
          };
          audio.onerror = () => {
            URL.revokeObjectURL(audioUrl);
            reject(new Error("Audio playback failed"));
          };
          audio.play().catch(reject);
        });
      } catch (error) {
        console.error("ElevenLabs TTS error:", error);
        // Fallback to Web Speech API
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = lang;
        window.speechSynthesis.speak(utterance);
      }
    },
    [ELEVENLABS_API_KEY]
  );

  // Enhanced speak function with sequential playback
  const speakText = useCallback(
    async (term: string, translation: string, fromLang: string, toLang: string) => {
      if (isSpeaking) return; // Prevent overlapping audio

      setIsSpeaking(true);

      try {
        // First speak the term in the original language
        await speakWithElevenLabs(term, fromLang);

        // Wait a bit before speaking the translation
        await new Promise((resolve) => setTimeout(resolve, 500));

        // Then speak the translation in the target language
        await speakWithElevenLabs(translation, toLang);
      } catch (error) {
        console.error("Error during text-to-speech:", error);
      } finally {
        setIsSpeaking(false);
      }
    },
    [isSpeaking, speakWithElevenLabs]
  );

  const toggleAccessModal = () => setAccessModalView((prev) => !prev);

  // Function to filter cards by selected status
  const getFilteredCards = () => {
    if (!vocabulary) return [];

    switch (selectedStatus) {
      case "all":
        return vocabulary.dictionary.cards;
      case "with_warnings":
        return vocabulary.dictionary.cards.filter((card) => card.status === "Controversial");
      case "no_warnings":
        return vocabulary.dictionary.cards.filter(
          (card) => card.status === "Private" || card.status === "Confirmed"
        );
      default:
        return vocabulary.dictionary.cards;
    }
  };

  // Get filtered cards
  const filteredCards = vocabulary ? getFilteredCards() : [];

  // Reset current slide index when filter changes
  useEffect(() => {
    setCurrentSlide(0);
  }, [selectedStatus]);

  if (error) {
    return (
      <PageWrapper>
        <div className="flex justify-center items-center min-h-screen">{t("vocabulary.noAccess")}</div>
      </PageWrapper>
    );
  }

  if (loading || !vocabulary) {
    return (
      <PageWrapper>
        <div className="flex justify-center items-center min-h-screen">
          <CircularProgress size={50} />
        </div>
      </PageWrapper>
    );
  }

  return (
    <PageWrapper>
      <Modal
        open={accessModalView}
        onClose={toggleAccessModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <AccessModal />
      </Modal>

      <div className="user-vocabulary pt-[20px] relative max-w-[1000px]">
        <div className="flex w-full justify-between">
          <span className="text-2xl">{vocabulary.dictionary.title}</span>
          <span>
            {t("vocabulary.creationDate")} {formatDate(vocabulary.dictionary.creationDate)}
          </span>
        </div>

        <div className="flex w-full justify-between">
          <span className="text-[#4F4F4F] text-xl">{vocabulary.dictionary.label}</span>
          <span className="text-m bg-[#F3D86D] p-2 rounded-[8px]">{vocabulary.dictionary.cefr}</span>
        </div>

        <span className="text-[#4F4F4F] w-full">{vocabulary.dictionary.description}</span>

        <div className="user-vocabulary__tests">
          <button
            onClick={() =>
              navigate(`/create-test/${id}`, { state: { vocName: vocabulary.dictionary.title } })
            }
            className="vocabulary-test"
          >
            {t("vocabulary.test")}
          </button>
        </div>

        <div className="relative w-[850px] flex justify-center">
          <Slider {...sliderSettings} beforeChange={(_, next) => setCurrentSlide(next)}>
            {vocabulary.dictionary.cards.map(({ term, translation }, index) => (
              <FlipCard key={index} word={term} translate={translation} />
            ))}
          </Slider>
        </div>

        <span>
          {t("vocabulary.pageCount", {
            current: currentSlide + 1,
            total: vocabulary.dictionary.cards.length,
          })}
        </span>

        <div className="user-vocabulary__termins">
          <div className="flex w-full justify-between">
            <div className="flex gap-4 items-center">
              <div className="w-[35px] h-[35px] bg-[red] rounded-full" />
              <div>user</div>
            </div>

            <div className="flex flex-end flex-col gap-5 items-end relative">
              <img src={moreInfo} onClick={() => setVocabularyOptions((prev) => !prev)} alt="moreInfo" />

              {vocabularyOptions && (
                <>
                  <div className="modalOverlayOptions" onClick={() => setVocabularyOptions(false)} />

                  <div className="flex flex-col bg-white border-1 voc-options gap-4 top-[20px] rounded-[10px] items-start w-[250px]">
                    {vocabulary.access === "Creator" && (
                      <>
                        <button onClick={toggleAccessModal}>{t("vocabulary.userOptions.grantAccess")}</button>
                        <button onClick={deleteVocabulary}>
                          {t("vocabulary.userOptions.deleteVocabulary")}
                        </button>
                      </>
                    )}
                    <button onClick={() => navigate(`/edit-vocabulary/${vocabulary.dictionary.id}`)}>
                      {t("vocabulary.userOptions.editVocabulary")}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="flex w-full justify-between items-center">
            <span>{t("vocabulary.termsSection")}</span>

            <Select
              className="formalization-option__select"
              value={selectedStatus}
              onChange={(event) => setSelectedStatus(event.target.value)}
              sx={{
                cursor: "pointer",
                borderRadius: "8px",
                color: "#4F4F4F",
              }}
            >
              {WORDS_STATUSES.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {t(`vocabulary.${option.label}`)}
                </MenuItem>
              ))}
            </Select>
          </div>

          <div className="termins">
            {filteredCards.length > 0 ? (
              filteredCards.map(({ term, translation, meaning, status }) => (
                <div key={term} className="termins-item gap-8">
                  <div className="flex w-full justify-between items-center">
                    <span>{term}</span>
                    <div className="flex flex-col gap-1 items-end">
                      <span>{translation}</span>
                      {meaning && (
                        <Tooltip title={meaning.length > 40 && meaning}>
                          <span>{slicedText(meaning, 40)}</span>
                        </Tooltip>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col gap-4">
                    {status === "Controversial" && <img src={warning} alt="" />}
                    <img
                      src={speaker}
                      alt="speaker"
                      onClick={() =>
                        speakText(
                          term,
                          translation,
                          vocabulary.dictionary.fromLang,
                          vocabulary.dictionary.toLang
                        )
                      }
                      className={`cursor-pointer ${isSpeaking ? "opacity-50" : ""}`}
                      style={{
                        pointerEvents: isSpeaking ? "none" : "auto",
                        filter: isSpeaking ? "grayscale(100%)" : "none",
                      }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="flex justify-center items-center p-4">{t("vocabulary.noTermsWithStatus")}</div>
            )}
          </div>
        </div>
      </div>
    </PageWrapper>
  );
};

export default Vocabulary;
