import "./index.scss";
import { formatDate } from "../../../utils/formatDate";
import lock from "../../../assets/lock.svg";
import { slicedText } from "../../../utils/slicedText";
import { Tooltip } from "@mui/material";

interface LibraryListProps {
  isFolder: boolean;
  id: string;
  description: string;
  isPublic: boolean;
  title: string;
  label: string;
  cefr: string;
  cardsCount: number;
  cards: any[];
  creationDate: string;
  onClick: () => void;
}

const LibraryItem: React.FC<LibraryListProps> = ({
  isFolder,
  description,
  title,
  isPublic,
  label,
  creationDate,
  onClick,
  cefr,
  cardsCount,
}) => {
  return (
    <div className="library-item" onClick={onClick}>
      <div className="library-top">
        <div className="library-top__intro">
          <div className="flex gap-3">
            <span>{title}</span>
            {!isPublic && <img src={lock} alt="lock" />}
          </div>

          <div className="flex gap-2">
            <span className="library-level">{label}</span>
          </div>
        </div>
        <div className="library-top__terms">
          <span>
            {cardsCount ? cardsCount : 0} {isFolder ? "sets" : "terms"}
          </span>
          {isFolder && (
            <span style={{ backgroundColor: "#F3D86D" }}>{cardsCount ? cardsCount : 0} terms</span>
          )}

          <span className="library-level !bg-[#F3D86D]">{cefr}</span>
        </div>
      </div>

      <Tooltip title={description.length > 40 && description}>
        <span>{slicedText(description, 60)}</span>
      </Tooltip>

      <div className="library-bottom flex w-full justify-between">
        <div className="library-bottom__user flex gap-1 items-center">
          <span className="user-photo" />
          <span className="user-name">User_name</span>
        </div>

        <span className="text-[#4F4F4F] text-sm">{formatDate(creationDate)}</span>
      </div>
    </div>
  );
};

export default LibraryItem;
