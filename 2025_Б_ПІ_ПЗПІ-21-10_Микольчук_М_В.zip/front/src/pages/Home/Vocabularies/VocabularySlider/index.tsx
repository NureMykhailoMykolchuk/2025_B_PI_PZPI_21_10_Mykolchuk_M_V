import Slider from "react-slick";

import sliderSettings from "./sliderSettings";
import VocabularyItem from "./VocabularyItem";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./index.scss";

const VocabularySlider = () => (
  <Slider {...sliderSettings}>
    {[1, 2, 3, 4, 5].map(() => (
      <VocabularyItem />
    ))}
  </Slider>
);

export default VocabularySlider;
