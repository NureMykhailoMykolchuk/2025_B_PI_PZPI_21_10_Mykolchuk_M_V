import vocabularyCreator from "../../../../../assets/vocabulary-creator.png";

import "./index.scss";

const VocabularyItem = () => {
  return (
    <div className="vocabulary">
      <div className="vocabulary-reduction">
        <span className="vocabulary-reduction__title">
          Technology Vocabulary
        </span>
        <span className="vocabulary-reduction__terms">45 термінів</span>
      </div>

      <div className="vocabulary-creator">
        <img
          src={vocabularyCreator}
          className="vocabulary-creator__photo"
          alt="vocabulary-user"
        />
        <span className="vocabulary-creator__name">osarcher</span>
      </div>
    </div>
  );
};

export default VocabularyItem;
