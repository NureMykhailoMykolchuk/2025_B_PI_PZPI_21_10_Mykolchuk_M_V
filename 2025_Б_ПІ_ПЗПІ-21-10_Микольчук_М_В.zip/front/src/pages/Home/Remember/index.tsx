import { useTranslation } from "react-i18next";
import "./index.scss";

const Remember = () => {
  const { t } = useTranslation();

  return (
    <div className="remember">
      <h2 className="remember-title">{t("homePage.remember.title")}</h2>
      <div className="remember-motivation">
        <div className="remember-motivation__item">{t("homePage.remember.motivation.you")}</div>
        <div className="remember-motivation__item">{t("homePage.remember.motivation.can")}</div>
        <div className="remember-motivation__item">{t("homePage.remember.motivation.do")}</div>
        <div className="remember-motivation__item">{t("homePage.remember.motivation.everything")}</div>
      </div>
    </div>
  );
};

export default Remember;
