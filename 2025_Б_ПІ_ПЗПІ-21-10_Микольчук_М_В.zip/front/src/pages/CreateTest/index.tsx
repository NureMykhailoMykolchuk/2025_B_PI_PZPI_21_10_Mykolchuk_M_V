import axios from "axios";
import { useForm } from "react-hook-form";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { HubConnectionBuilder, HttpTransportType, HubConnection } from "@microsoft/signalr";
import { useTranslation } from "react-i18next";

import "./index.scss";

export const CreateTest = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const vocName = location.state?.vocName || t("createTest.defaultTitle");
  const isRoomTest = location.state?.isRoomTest || false;
  const [ownDictionaries, setOwnDictionaries] = useState<any[]>([]);
  const [filteredDictionaries, setFilteredDictionaries] = useState<any[]>([]);
  const [selectedDictionaries, setSelectedDictionaries] = useState<string[]>([]);
  const [isCreatingRoom, setIsCreatingRoom] = useState(false);
  const { register, handleSubmit } = useForm({
    defaultValues: {
      roomName: "",
      questionsNumber: "",
      questionTypes: {
        definition: false,
        translation: false,
        grammar: false,
        audioRecord: false,
        audioListen: false,
      },
    },
  });

  const navigate = useNavigate();
  const { id } = useParams();
  const connectionRef = useRef<HubConnection | null>(null);

  useEffect(() => {
    if (!isRoomTest) return;

    const fetchDictionaries = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get("https://localhost:7288/Dictionary/own", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setOwnDictionaries(response.data);
        setFilteredDictionaries(response.data);
      } catch (error) {
        console.error(t("createTest.errors.loadingDictionaries"), error);
      }
    };

    fetchDictionaries();

    return () => {
      // Clean up connection if component unmounts
      if (connectionRef.current) {
        connectionRef.current.stop();
      }
    };
  }, [isRoomTest, t]);

  const questionTypeMapping: any = {
    definition: 4,
    translation: 2,
    grammar: 1,
    audioRecord: 5,
    audioListen: 3,
  };

  const toggleDictionarySelection = (dictionary: any) => {
    const dictionaryId = dictionary.id;

    if (selectedDictionaries.includes(dictionaryId)) {
      // If we're deselecting a dictionary, just remove it from selection
      setSelectedDictionaries((prev) => prev.filter((id) => id !== dictionaryId));
      // No filtering needed when deselecting
      setFilteredDictionaries(ownDictionaries);
    } else {
      // We're selecting a dictionary
      setSelectedDictionaries((prev) => [...prev, dictionaryId]);

      // If this is the first dictionary selected, filter the list
      if (selectedDictionaries.length === 0) {
        const selectedFromLang = dictionary.fromLang;
        const selectedToLang = dictionary.toLang;

        // Filter dictionaries to only show those with matching language pairs
        const filtered = ownDictionaries.filter(
          (dict) => dict.fromLang === selectedFromLang && dict.toLang === selectedToLang
        );

        setFilteredDictionaries(filtered);
      }
    }
  };

  // Reset filters if all dictionaries are deselected
  useEffect(() => {
    if (selectedDictionaries.length === 0) {
      setFilteredDictionaries(ownDictionaries);
    }
  }, [selectedDictionaries, ownDictionaries]);

  const createAndJoinRoom = async (testData: any, roomName: string) => {
    setIsCreatingRoom(true);
    const token = localStorage.getItem("token");

    try {
      // Create a new connection to RoomsHub
      const roomsConnection = new HubConnectionBuilder()
        .withUrl(`https://localhost:7288/rooms?access_token=${token}`, {
          transport: HttpTransportType.WebSockets,
        })
        .withAutomaticReconnect()
        .build();

      // Store in ref for cleanup
      connectionRef.current = roomsConnection;

      await roomsConnection.start();

      // Set up the redirect listener before invoking AddRoom
      roomsConnection.on("RedirectToRoom", async (roomId: string) => {
        navigate(`/room/${roomId}`);
      });

      // Pass roomName as second parameter to AddRoom
      await roomsConnection.invoke("AddRoom", testData, roomName);
    } catch (error) {
      console.error(t("createTest.errors.creatingRoom"), error);
      setIsCreatingRoom(false);
    }
  };

  const onSubmit = async (data: any) => {
    const selectedQuestionTypes = Object.keys(data.questionTypes)
      .filter((key) => data.questionTypes[key])
      .map((key) => questionTypeMapping[key]);

    // Validate that at least one question type is selected
    if (selectedQuestionTypes.length === 0) {
      alert(t("createTest.validation.selectQuestionType"));
      return;
    }

    // Validate dictionary selection for room tests
    if (isRoomTest && selectedDictionaries.length === 0) {
      alert(t("createTest.validation.selectDictionary"));
      return;
    }

    // Validate room name for room tests
    if (isRoomTest && !data.roomName.trim()) {
      alert(t("createTest.validation.enterRoomName"));
      return;
    }

    const payload = {
      questionsNumber: parseInt(data.questionsNumber),
      questionTypes: selectedQuestionTypes,
      dictionariesId: isRoomTest ? selectedDictionaries : [id],
    };

    try {
      const response = await axios.post("https://localhost:7288/Test", payload);

      if (isRoomTest) {
        await createAndJoinRoom(response.data, data.roomName);
      } else {
        navigate(`/test/${id}`, { state: { testData: response.data } });
      }
    } catch (error) {
      console.error(t("createTest.errors.creatingTest"), error);
      if (isRoomTest) {
        setIsCreatingRoom(false);
      }
    }
  };

  return (
    <div className="w-full flex items-center justify-center">
      <div className="flex flex-col gap-20 w-[1200px] mt-10 items-center">
        <div className="flex justify-between items-center mb-8 border-b pb-4 w-full">
          <span className="text-xl font-semibold">{vocName}</span>
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full">
            X
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="w-full flex flex-col items-center">
          {isRoomTest && (
            <div className="mb-8 p-3 w-full flex justify-between items-center border border-1 rounded-[8px]">
              <label className="block text-lg font-medium mb-2">
                {t("createTest.roomName") || "Назва змагання"}
              </label>
              <input
                type="text"
                {...register("roomName", { required: isRoomTest })}
                className="w-[300px] p-3 border bg-[#F3D86D] rounded-lg focus:outline-none"
                placeholder={t("createTest.roomNamePlaceholder") || "Введіть назву змагання"}
              />
            </div>
          )}

          <div className="mb-8 p-3 w-full flex justify-between items-center border border-1 rounded-[8px]">
            <label className="block text-lg font-medium mb-2">{t("createTest.questionsNumber")}</label>
            <input
              type="text"
              {...register("questionsNumber", { required: true, min: 1 })}
              className="w-[100px] text-center p-3 border bg-[#F3D86D] rounded-lg focus:outline-none"
            />
          </div>

          <div className="mb-8 p-3 w-full flex justify-between border border-1 rounded-[8px]">
            <span className="block text-lg font-medium mb-4">{t("createTest.questionTypes.title")}</span>
            <div className="bg-gray-50 p-6 space-y-4">
              {[
                { label: t("createTest.questionTypes.definition"), key: "definition" },
                { label: t("createTest.questionTypes.translation"), key: "translation" },
                { label: t("createTest.questionTypes.grammar"), key: "grammar" },
                { label: t("createTest.questionTypes.audioRecord"), key: "audioRecord" },
                { label: t("createTest.questionTypes.audioListen"), key: "audioListen" },
              ].map(({ label, key }) => (
                <div key={key} className="flex justify-between items-center">
                  <span className="text-base mr-2">{label}</span>
                  <label style={{ display: "inline-block" }}>
                    <input
                      type="checkbox"
                      {...register(`questionTypes.${key}`)}
                      style={{ display: "none" }}
                      id={`questionTypes.${key}`}
                    />
                    <span className="custom-checkbox" />
                  </label>
                </div>
              ))}
            </div>
          </div>

          {isRoomTest && (
            <div className="mb-8 w-full">
              <span className="block text-lg font-medium mb-4">{t("createTest.dictionaries.title")}</span>
              {selectedDictionaries.length > 0 && (
                <div className="mb-2 p-2 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-700">{t("createTest.dictionaries.filterInfo")}</p>
                </div>
              )}
              <div className="bg-gray-50 p-6 rounded-lg border space-y-4 max-h-[300px] overflow-y-auto">
                {filteredDictionaries.length === 0 ? (
                  <p>{t("createTest.dictionaries.notFound")}</p>
                ) : (
                  filteredDictionaries.map((dict) => (
                    <div
                      key={dict.id}
                      className="flex justify-between items-center p-4 bg-white border rounded-lg shadow-sm hover:shadow-md transition-shadow"
                    >
                      <div>
                        <a
                          href={`/vocabulary/${dict.id}`}
                          className="text-blue-600 text-lg font-semibold hover:underline"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {dict.title}
                        </a>
                        <div className="text-sm text-gray-600">
                          {t("createTest.dictionaries.level")}:{" "}
                          <span className="font-medium">{dict.cefr}</span>
                        </div>
                        <div className="text-sm text-gray-600">
                          {t("createTest.dictionaries.topic")}:{" "}
                          <span className="font-medium">{dict.label}</span>
                        </div>
                        <div className="text-sm text-gray-600">
                          {t("createTest.dictionaries.languages")}:{" "}
                          <span className="font-medium">
                            {dict.fromLang} → {dict.toLang}
                          </span>
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={selectedDictionaries.includes(dict.id)}
                        onChange={() => toggleDictionarySelection(dict)}
                        className="w-5 h-5"
                      />
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isCreatingRoom}
            className={`w-[250px] ${
              isCreatingRoom ? "bg-gray-400" : "bg-[#CBD1FF] hover:bg-blue-700"
            } text-black py-3 rounded-lg font-medium transition-colors`}
          >
            {isCreatingRoom
              ? t("createTest.buttons.creatingRoom")
              : isRoomTest
              ? t("createTest.buttons.createRoom")
              : t("createTest.buttons.startTest")}
          </button>
        </form>
      </div>
    </div>
  );
};
