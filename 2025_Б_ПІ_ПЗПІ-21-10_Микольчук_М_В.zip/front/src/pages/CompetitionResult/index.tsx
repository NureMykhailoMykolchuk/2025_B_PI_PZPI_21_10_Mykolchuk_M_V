import PageWrapper from "../../components/PageWrapper";

export const CompetitionResult = () => {
  return <PageWrapper>test</PageWrapper>;
};
