export const LANG_OPTIONS = [
  { value: "ua", label: "Українська" },
  { value: "en", label: "Англійська" },
];
