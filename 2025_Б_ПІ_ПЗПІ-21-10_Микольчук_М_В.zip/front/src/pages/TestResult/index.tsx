import { useLocation, useNavigate } from "react-router-dom";
import { PieChart } from "react-minimal-pie-chart";
import salute from "../../assets/result-salute.png";
import { useEffect, useState } from "react";
import cardsIcon from "../../assets/cards.svg";
import audio from "../../assets/speaker-button.svg";
import clsx from "clsx";
import { useSelector } from "react-redux";
import { RootState, store } from "../../store/store";
import { CircularProgress } from "@mui/material";
import { refresh } from "../../store/race/raceSlice";
import { useTranslation } from "react-i18next";

export const TestResult = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const { resultData, isRace } = location.state;
  const raceResult = useSelector((state: RootState) => state.race.raceResult);

  console.log("resultData", resultData);
  console.log("raceResult", raceResult);
  console.log("isRace", isRace);

  const totalAnswers = resultData?.questions?.length || 0;
  const correctPercentage =
    totalAnswers > 0 ? Math.round((resultData.correctAnswers / totalAnswers) * 100) : 0;
  const incorrectPercentage =
    totalAnswers > 0 ? Math.round((resultData.incorrectAnswers / totalAnswers) * 100) : 0;

  const handleClose = () => {
    navigate("/", { replace: true, state: null });
  };

  const navigateToVocabulary = () => {
    navigate(`/vocabulary/${resultData.dictionaryId}`, { replace: true, state: null });
  };

  const formatTime = (time: string) => {
    const parts = time.split(":");
    const minutes = parts[1];
    const seconds = parts[2].slice(0, 5);
    return `${minutes}:${seconds}`;
  };

  useEffect(() => {
    return () => {
      store.dispatch(refresh());

      if (window.history.state?.state) {
        window.history.replaceState(
          { ...window.history.state, state: null },
          document.title,
          window.location.pathname
        );
      }
    };
  }, []);

  if (!resultData) {
    navigate("/", { replace: true });
    return null;
  }

  return (
    <div className="flex flex-col gap-10 items-center">
      <div className="flex justify-center relative w-full">
        <span>{resultData.dictionaryName}</span>
        <span className="absolute right-0 cursor-pointer" onClick={handleClose}>
          {t("testResult.close")}
        </span>
      </div>

      <div className="w-[1100px]">
        <div className="flex items-center justify-between">
          <span className="text-3xl">
            {t("testResult.yourResult")} {`${resultData.correctAnswers}/${totalAnswers}`}
            {t("testResult.keepItUp")}
          </span>
          <img className="w-[200px]" src={salute} alt="salute" />
        </div>

        <div className="w-full flex justify-between mb-8">
          <div className="flex items-center w-[48%] gap-3 justify-between">
            <PieChart
              data={[
                { value: resultData.correctAnswers, color: "#90FF88" },
                { value: resultData.incorrectAnswers, color: "#FF6E6E" },
              ]}
              className="w-[150px]"
            />

            <div className="flex flex-col gap-4 flex-1">
              <div>
                <span>{t("testResult.answerStats.correctAnswers")} </span>
                <span>
                  {resultData.correctAnswers} ({correctPercentage}%)
                </span>
              </div>
              <div>
                <span>{t("testResult.answerStats.incorrectAnswers")} </span>
                <span>
                  {resultData.incorrectAnswers} ({incorrectPercentage}%)
                </span>
              </div>
            </div>
          </div>

          <div
            className="w-[48%] flex justify-between gap-6 p-3 items-center border-2 rounded-[15px] cursor-pointer"
            onClick={navigateToVocabulary}
          >
            <img className="w-[70px] h-[70px]" src={cardsIcon} alt="cards" />

            <div className="flex flex-col gap-4">
              <span className="text-2xl">{t("testResult.dictionaryReturn.returnToDictionary")}</span>
              <span className="text-[#4F4F4F]">{t("testResult.dictionaryReturn.description")}</span>
            </div>
          </div>
        </div>

        {isRace && (
          <div className="bg-[#CBD1FF] rounded-[15px] p-5 flex justify-start min-h-[300px] mb-3 flex-col items-center">
            <span>{t("testResult.competition.results")}</span>

            {!raceResult || raceResult.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40">
                <span>{t("testResult.competition.waitForOthers")}</span>
                <CircularProgress />
              </div>
            ) : (
              <div className="flex flex-col gap-3 w-full">
                <div className="flex justify-end w-full gap-4">
                  <span>{t("testResult.competition.time")}</span>
                  <span>{t("testResult.competition.points")}</span>
                </div>
                {raceResult.map((participant: any, index: number) => (
                  <div key={index} className="flex w-full justify-between">
                    <div className="flex gap-2 items-center">
                      <div
                        className="w-[35px] h-[35px] rounded-full"
                        style={{ backgroundColor: participant.participant.image || "red" }}
                      />
                      <span>{participant.participant.email}</span>
                    </div>

                    <div className="flex w-[120px] justify-between">
                      <span>{formatTime(participant.time)}</span>
                      <span>{participant.score || 4}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="w-full">
          <h2 className="text-2xl mb-4">{t("testResult.answers.yourAnswers")}</h2>
          <div className="space-y-6 flex flex-col gap-4 mb-6">
            {resultData.questions.map((question: any, index: any) =>
              question?.type === "trueFalse" ? (
                <div
                  key={index}
                  className="bg-white rounded-lg shadow-lg p-6 mb-8 gap-4 border min-h-[300px] relative"
                >
                  <div className="flex w-full justify-between">
                    <div className="flex flex-col gap-1 w-[50%]">
                      <span>{t("testResult.answers.term")}</span>
                      <span className="text-3xl">{question?.term}</span>
                    </div>
                    <div className="w-[2px] bg-[#D9D9D9]" />
                    <div className="flex flex-col gap-1 w-[50%] pl-[50px]">
                      <span>{t("testResult.answers.meaning")}</span>
                      <span className="text-3xl">{question?.translation}</span>
                    </div>
                  </div>
                  <div className="flex w-full flex-wrap justify-between gap-3 mt-3">
                    {question?.answers.map((answer: any, answerIndex: any) => {
                      const isSelected = question.GivenAnswer === answer.choice.toString();
                      const isCorrectAnswer = answer.isCorrect;
                      let borderColor = "border-gray-500";
                      if (isSelected) {
                        borderColor = isCorrectAnswer ? "border-green-500" : "border-red-500";
                      } else if (isCorrectAnswer && !question.IsGivenCorrectAnswer) {
                        borderColor = "border-green-500";
                      }

                      return (
                        <div
                          key={answerIndex}
                          className={`w-[45%] rounded-[8px] p-3 border-2 ${borderColor} flex gap-3`}
                        >
                          <span className="rounded-full border text-[#8B8B8B] w-[25px] h-[25px] flex justify-center bg-[#EEEEEE]">
                            {answerIndex + 1}
                          </span>
                          <span>{answer.choice.toString()}</span>
                        </div>
                      );
                    })}
                  </div>

                  <div
                    className={clsx(
                      "rounded-[8px] w-full absolute left-0 bottom-0 p-4 flex justify-center",
                      question.IsGivenCorrectAnswer ? "bg-[#BDFFC5]" : "bg-[#FFACAB]"
                    )}
                  >
                    {question.IsGivenCorrectAnswer
                      ? t("testResult.answers.correct")
                      : t("testResult.answers.incorrect")}
                  </div>
                </div>
              ) : (
                <div
                  key={index}
                  className="bg-white rounded-lg shadow-lg p-6 mb-8 border relative min-h-[300px]"
                >
                  <div className="w-full flex justify-between items-center">
                    <span>{t("testResult.answers.term")}</span>
                    <img src={audio} alt="audio" />
                  </div>
                  <span className="text-3xl">{question?.term || question?.translation}</span>
                  <div className="mt-6 mb-[20px]">
                    <div className="flex w-full flex-wrap justify-between gap-3 mt-3">
                      {question?.answers.map((answer: any, answerIndex: any) => {
                        const isSelected = question.GivenAnswer === answer.text;
                        const isCorrectAnswer = answer.isCorrect;
                        let borderColor = "border-gray-500";
                        if (isSelected) {
                          borderColor = isCorrectAnswer ? "border-green-500" : "border-red-500";
                        } else if (isCorrectAnswer && !question.IsGivenCorrectAnswer) {
                          borderColor = "border-green-500";
                        }

                        return (
                          <div
                            key={answerIndex}
                            className={`w-[45%] rounded-[8px] p-3 border-2 ${borderColor} flex gap-3`}
                          >
                            <span className="rounded-full border text-[#8B8B8B] w-[25px] h-[25px] flex justify-center bg-[#EEEEEE]">
                              {answerIndex + 1}
                            </span>
                            <span>{answer.text}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div
                    className={clsx(
                      "rounded-[8px] w-full absolute left-0 bottom-0 p-4 flex justify-center",
                      question.IsGivenCorrectAnswer ? "bg-[#BDFFC5]" : "bg-[#FFACAB]"
                    )}
                  >
                    {question.IsGivenCorrectAnswer
                      ? t("testResult.answers.correct")
                      : t("testResult.answers.incorrect")}
                  </div>
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
